export * from './home'
export * from './detail'
export * from './location'
export * from './dealer'
export * from './img'

